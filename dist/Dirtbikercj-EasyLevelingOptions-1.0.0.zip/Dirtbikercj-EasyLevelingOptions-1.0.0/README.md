All info(AI) by dirtbikercj

Simple mod to either simply increase your leveling rate, or adjust them to your specific liking.

bool = true/false
number = 1, 1.2, 0.00010

Config:

EnabledMod - Enables or disables mod. (Type: bool)
SimpleLevelingRate - Simple leveling multplier. (2 would be 2x normal rate)                     (Type: number)
EnableSkillFatique - Enables or disables skill fatique.                                         (Type: bool)
EnableSkillAtrophy - Enables or disables skill atrophy(skill regression).                       (Type: bool)

EnableAdvancedAdjustments - Enables advanced adjustments, when enabled skilling rates will be based off below numbers and SimpleLevelingRate will no longer do anything. (type: bool)
SkillMinEffectiveness - Minimum ammount of skills gain per action.                              (type: number)
SkillFatiquePerPoint - Skill Fatique added per skill point gained.                              (type: number)
SkillFreshEffectiveness - Skill point gain multiplier while fresh.                              (type: number)
SkillFreshPoints - Ammount of fresh skill points.                                               (type: number)
SkillPointsBeforeFatique - Ammount of skill points gained before skill fatique kicks in .       (type: number)
SkillFatiqueReset - Time before skill fatique resets.                                           (type: number)
SkillExpPerLevel - Ammount of base points needed to gain a level.                               (Type: number)